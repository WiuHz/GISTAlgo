from __future__ import annotations

import argparse
import os
import sys
import time
from functools import lru_cache

import numpy as np
from scipy import ndimage
from scipy.signal import fftconvolve

IMG_SIZE = 128
GRID = (4, 4)
FREQUENCIES = (0.1, 0.2, 0.4)
ORIENTATIONS = tuple(np.pi * k / 5 for k in range(5))
N_STDS = 3.0

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_DATA_DIR = os.path.join(HERE, "Opcode_Matrices", "Opcode_Matrices", "matrices_uint8")


@lru_cache(maxsize=1)
def build_gabor_filter_bank(
    frequencies: tuple[float, ...] = FREQUENCIES,
    orientations: tuple[float, ...] = ORIENTATIONS,
) -> tuple[np.ndarray, ...]:
    kernels = []
    for freq in frequencies:
        sigma = 0.56 / freq
        half = max(int(np.ceil(N_STDS * sigma)), 1)
        y, x = np.mgrid[-half : half + 1, -half : half + 1].astype(np.float32)
        for theta in orientations:
            xr = x * np.cos(theta) + y * np.sin(theta)
            yr = -x * np.sin(theta) + y * np.cos(theta)
            envelope = np.exp(-(xr**2 + yr**2) / (2.0 * sigma**2))
            kernel = envelope * np.exp(2j * np.pi * freq * xr)
            kernel -= kernel.mean()
            kernel /= np.abs(kernel).sum() + 1e-12
            kernels.append(kernel.astype(np.complex64))
    return tuple(kernels)


def _read_png(path: str) -> np.ndarray:
    try:
        from PIL import Image
    except ImportError as exc:
        raise RuntimeError("Pillow is required to read .png files; use .npy or pip install pillow") from exc
    with Image.open(path) as im:
        return np.asarray(im.convert("L"))


def load_matrix(path: str | os.PathLike) -> np.ndarray:
    path_str = str(path)
    if path_str.endswith(".npy"):
        arr = np.load(path_str)
    elif path_str.endswith(".png"):
        arr = _read_png(path_str)
    else:
        raise ValueError(f"Unsupported file format: {path_str}")
    
    if arr.ndim != 2:
        raise ValueError(f"Matrix must be 2D, got shape={arr.shape}: {path_str}")
    return arr


def prepare_image(matrix: np.ndarray, size: int = IMG_SIZE) -> np.ndarray:
    arr = np.asarray(matrix, dtype=np.float32)
    if arr.max() > 1.0:
        arr = arr / 255.0
    if arr.shape != (size, size):
        factor = (size / arr.shape[0], size / arr.shape[1])
        arr = ndimage.zoom(arr, factor, order=1)
    return np.clip(arr, 0.0, 1.0).astype(np.float32)


def extract_gist_descriptor(image, grid_size: tuple[int, int] = GRID) -> np.ndarray:
    matrix = load_matrix(image) if isinstance(image, (str, os.PathLike)) else image
    img = prepare_image(matrix)
    kernels = build_gabor_filter_bank()
    gh, gw = grid_size
    cell_h = img.shape[0] // gh
    cell_w = img.shape[1] // gw

    features = np.empty(len(kernels) * gh * gw, dtype=np.float32)
    idx = 0
    for kernel in kernels:
        energy = np.abs(fftconvolve(img, kernel, mode="same"))
        for i in range(gh):
            for j in range(gw):
                cell = energy[i * cell_h : (i + 1) * cell_h, j * cell_w : (j + 1) * cell_w]
                features[idx] = cell.mean()
                idx += 1
    return features


def collect_samples(data_dir: str, limit_per_class: int | None = None) -> list[tuple[str, str]]:
    samples: list[tuple[str, str]] = []
    for label in sorted(os.listdir(data_dir)):
        class_dir = os.path.join(data_dir, label)
        if not os.path.isdir(class_dir):
            continue
        names = sorted(n for n in os.listdir(class_dir) if n.endswith((".npy", ".png")))
        if limit_per_class is not None:
            names = names[:limit_per_class]
        samples.extend((os.path.join(class_dir, n), label) for n in names)
    return samples


def main() -> None:
    for stream in (sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            stream.reconfigure(encoding="utf-8", errors="replace")

    parser = argparse.ArgumentParser(description="Extract GIST features for opcode matrices")
    parser.add_argument("--data-dir", default=DEFAULT_DATA_DIR)
    parser.add_argument("--out", default=os.path.join(HERE, "gist_features", "gist_features.npz"))
    parser.add_argument("--limit", type=int, default=None, help="max samples per class (for quick testing)")
    parser.add_argument("--csv", action="store_true", help="also export to CSV")
    args = parser.parse_args()

    samples = collect_samples(args.data_dir, args.limit)
    if not samples:
        raise SystemExit(f"No valid .npy/.png files found in {args.data_dir}")

    t0 = time.perf_counter()
    n_samples = len(samples)
    n_features = len(build_gabor_filter_bank()) * GRID[0] * GRID[1]
    
    X = np.empty((n_samples, n_features), dtype=np.float32)
    y = np.array([label for _, label in samples])
    paths = np.array([p for p, _ in samples])

    for idx, (path, _) in enumerate(samples):
        X[idx] = extract_gist_descriptor(path)
        if (idx + 1) % 200 == 0 or idx + 1 == n_samples:
            elapsed = time.perf_counter() - t0
            rate = (idx + 1) / elapsed
            print(f"  [{idx + 1}/{n_samples}] {rate:.1f} samples/s | ETA: ~{(n_samples - idx - 1) / rate:.0f}s")

    total_time = time.perf_counter() - t0
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    np.savez_compressed(args.out, X=X, y=y, paths=paths)

    print(f"\nDone: {X.shape[0]} samples × {X.shape[1]} features ({total_time:.1f}s, {X.shape[0] / total_time:.1f} samples/s)")
    print("Saved to:", args.out)
    
    labels, counts = np.unique(y, return_counts=True)
    for label, count in zip(labels, counts):
        print(f"  {label:<22} {count}")

    if args.csv:
        import pandas as pd
        csv_path = os.path.splitext(args.out)[0] + ".csv"
        columns = [f"gist_{i}" for i in range(X.shape[1])]
        pd.DataFrame(X, columns=columns).assign(label=y).to_csv(csv_path, index=False)
        print("CSV saved to:", csv_path)


if __name__ == "__main__":
    main()