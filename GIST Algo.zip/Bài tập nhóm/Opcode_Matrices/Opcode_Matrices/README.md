# Opcode Pair Matrices

Each file is represented by a dense adjacency matrix of consecutive opcode pairs. Rows are the previous opcode, columns are the next opcode, and each cell counts that transition. The per-file maximum count is normalized to grayscale value 255.

- `opcode_vocabulary.csv`: global opcode-to-index mapping.
- `matrices_uint8/`: normalized matrices stored as NumPy uint8 `.npy` files.
- `images_grayscale/`: the same matrices as grayscale PNG files.
- `matrix_manifest.csv`: source labels and output paths.
- `summary.json`: dimensions and normalization rule.
